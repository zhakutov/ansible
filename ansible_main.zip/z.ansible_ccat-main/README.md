# ansible-3h
# these files are demo files for my ansible in 3 hours session
# on safaribooksonline. 

